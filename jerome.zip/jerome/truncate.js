document.addEventListener("DOMContentLoaded", function() {
    const firstBubble = document.querySelector(".bubble:first-of-type");
    if (firstBubble) {
      firstBubble.style.display = "none";
    }
  });